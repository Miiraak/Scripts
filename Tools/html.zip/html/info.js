document.addEventListener("DOMContentLoaded", function () {
    // Affiche la date de démarrage
    document.getElementById('start').textContent = new Date().toLocaleString();
    // Footer date
    document.getElementById('footerDate').textContent = new Date().toLocaleDateString();
});